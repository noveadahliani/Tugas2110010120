/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package salary;

/**
 *
 * @author User
 */
public class tblabsensipegawai {
    private int NIPPOS, Tanggal;
    private String Nama, Waktu_masuk, Waktu_keluar;
    
    
    public tblabsensipegawai(){}
    
    public void setTanggal (int Tanggal){
        this.Tanggal=Tanggal;
    }
    public int getTanggal(){
        return this.Tanggal;
    }
    public void setNIPPOS (int NIPPOS){
        this.NIPPOS=NIPPOS;
    }
    public int getNIPPOS(){
        return this.NIPPOS;
    }
    public void setNama (String Nama){
        this.Nama=Nama;
    }
    public String getNama(){
        return this.Nama;
    }
    public void setWaktu_masuk (String Waktu_masuk){
        this.Waktu_masuk=Waktu_masuk;
    }
    public String getWaktu_masuk(){
        return this.Waktu_masuk;
    }
    public void setWaktu_keluar (String Waktu_keluar){
        this.Waktu_keluar=Waktu_keluar;
    }
    public String getWaktu_keluar(){
        return this.Waktu_keluar;
    }
}
    

