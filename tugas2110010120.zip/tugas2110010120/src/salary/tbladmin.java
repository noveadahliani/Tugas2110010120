/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package salary;

/**
 *
 * @author User
 */
public class tbladmin {
    private int id,Username,Password,Dibuat_pada;
    private String Nama_pertama,Nama_belakang,Mengisi,Mengubah,Melihat,Menghapus;
    
    
    public tbladmin(){}
    
     public void setid (int id){
        this.id=id;
    }
    public int getid(){
        return this.id;
    }
     public void setUsername (int Username){
        this.Username=Username;
    }
     public int getUsername(){
        return this.Username;
    }
     public void setPassword (int Password){
        this.Password=Password;
    }
    public int getPassword(){
        return this.Password;
    }
     public void setDibuat_pada (int Dibuat_pada){
        this.Dibuat_pada=Dibuat_pada;
    }
    public int getDibuat_pada(){
        return this.Dibuat_pada;
    }
     public void setNama_pertama (String Nama_pertama){
        this.Nama_pertama=Nama_pertama;
    }
    public String getNama_pertama(){
        return this.Nama_pertama;
    }
     public void setNama_belakang (String Nama_belakang){
        this.Nama_belakang=Nama_belakang;
    }
    public String getNama_belakang(){
        return this.Nama_belakang;
    }
     public void setMengisi (String Mengisi){
        this.Mengisi=Mengisi;
    }
    public String getMengisi(){
        return this.Mengisi;
    }
     public void setMengubah (String Mengubah){
        this.Mengubah=Mengubah;
    }
    public String getMengubah(){
        return this.Mengubah;
    }
     public void setMelihat (String Melihat ){
        this.Melihat=Melihat;
    }
    public String getMelihat(){
        return this.Melihat;
    }
     public void setMenghapus (String Menghapus){
        this.Menghapus=Menghapus;
    }
    public String getMenghapus(){
        return this.Menghapus;
    }
}
