/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package salary;

/**
 *
 * @author User
 */
public class tbllogin {
    private int NIPPOS, Password, Login;
    
    
    public tbllogin(){}
    
    public void setNIPPOS (int NIPPOS){
        this.NIPPOS=NIPPOS;
    }
    public int getNIPPOS(){
        return this.NIPPOS;
    }
    public void setPassword (int Password){
        this.Password=Password;
    }
    public int getPassword(){
        return this.Password;
    }
    public void setLogin (int Login){
        this.Login=Login;
    }
    public int getLogin(){
        return this.Login;
    }
}
