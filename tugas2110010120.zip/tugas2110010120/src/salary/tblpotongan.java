/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package salary;

/**
 *
 * @author User
 */
public class tblpotongan {
    private int Potongan, Jumlah;
   
    public tblpotongan(){}
    
    public void setPotongan (int Potongan){
        this.Potongan=Potongan;
    }
    public int getPotongan(){
        return this.Potongan;
    }
    public void setJumlah (int Jumlah){
        this.Jumlah=Jumlah;
    }
    public int getTanggal(){
        return this.Jumlah;
    }
    
}
