/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package salary;

/**
 *
 * @author User
 */
public class tbldatapegawai {
    private int NIPPOS,Password,Pegawai_sejak;
    private String Nama,Posisi,Jadwal,Melihat,Mengisi;
    
  
    public tbldatapegawai(){}
    
    public void setNIPPOS (int tNIPPOS){
        this.NIPPOS=NIPPOS;
    }
    public int getNIPPOS(){
        return this.NIPPOS;
    }
    public void setPassword (int Password){
        this.Password=Password;
    }
    public int getPassword(){
        return this.Password;
    }
    public void setPegawai_sejak (int Pegawai_sejak){
        this.Pegawai_sejak=Pegawai_sejak;
    }
    public int getPegawai_sejak(){
        return this.Pegawai_sejak;
    }
    public void setNama (String Nama){
        this.Nama=Nama;
    }
    public String getNama(){
        return this.Nama;
    }
    public void setPosisi (String Posisi){
        this.Posisi=Posisi;
    }
    public String getPosisi(){
        return this.Posisi;
    }
    public void setJadwal (String Jadwal){
        this.Jadwal=Jadwal;
    }
    public String getJadwal (){
        return this.Jadwal ;
    }
    public void setMelihat (String Melihat){
        this.Melihat=Melihat;
    }
    public String getMelihat(){
        return this.Melihat;
    }
    public void setMengisi (String Mengisi){
        this.Mengisi=Mengisi;
    }
    public String getMengisi(){
        return this.Mengisi;
    }
}
